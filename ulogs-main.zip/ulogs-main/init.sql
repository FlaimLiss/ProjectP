CREATE TABLE user_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(255) NULL,
    fullName VARCHAR(255) NULL,
    isAdmin TINYINT(1) NOT NULL DEFAULT 0,  -- 1 для администратора, 0 для обычного пользователя
    hostname VARCHAR(255) NULL,
    osVersion VARCHAR(255) NULL,
    ipAddress VARCHAR(255) NULL,  -- Сохраняем IPv4-адреса
    macAddress VARCHAR(255) NULL,  -- Сохраняем MAC-адреса
    processorModel VARCHAR(255) NULL,
    mainboardModel VARCHAR(255) NULL,
    totalMemory VARCHAR(255) NULL,
    createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Заполнение таблицы user_logs
INSERT INTO user_logs (login, fullName, hostname, osVersion, ipAddress, macAddress, processorModel, mainboardModel, totalMemory) VALUES 
('user1', 'Иван Иванов', 'host1', 'Windows 10', '192.168.1.1', '00:1A:2B:3C:4D:5E', 'Intel Core i5', 'ASUS ROG', '16GB'),
('user2', 'Петр Петров', 'host2', 'Ubuntu 20.04', '192.168.1.2', '00:1A:2B:3C:4D:5F', 'AMD Ryzen 5', 'Gigabyte B450', '16GB'),
('user3', 'Светлана Светлова', 'host3', 'macOS Big Sur', '192.168.1.3', '00:1A:2B:3C:4D:5G', 'Apple M1', 'Apple', '8GB'),
('user4', 'Алексей Алексеев', 'host4', 'Windows 7', '192.168.1.4', '00:1A:2B:3C:4D:5H', 'Intel Core i3', 'MSI', '8GB'),
('user5', 'Мария Мариева', 'host5', 'Linux Mint', '192.168.1.5', '00:1A:2B:3C:4D:5I', 'Intel Core i7', 'ASRock', '32GB');

CREATE TABLE companies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    weight INT NOT NULL DEFAULT 0 CHECK (weight >= 0),
    UNIQUE (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    weight INT NOT NULL DEFAULT 0 CHECK (weight >= 0),
    UNIQUE (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE branches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    weight INT NOT NULL DEFAULT 0 CHECK (weight >= 0),
    UNIQUE (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE positions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    weight INT NOT NULL DEFAULT 0 CHECK (weight >= 0),
    UNIQUE (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    department_id INT NOT NULL,
    branch_id INT NOT NULL,
    position_id INT NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    internal_phone_number VARCHAR(4) NOT NULL,
    external_phone_number VARCHAR(255),
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE RESTRICT,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT,
    FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE RESTRICT,
    FOREIGN KEY (position_id) REFERENCES positions(id) ON DELETE RESTRICT,
    weight INT NOT NULL DEFAULT 0 CHECK (weight >= 0),
    UNIQUE (internal_phone_number, company_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message_key VARCHAR(255) NOT NULL UNIQUE,   
    message_value TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Заполнение таблицы messages
INSERT INTO messages (message_key, message_value) VALUES 
('call_rules', 'Межгород 8(XXXX)XXXXXX, Мобильный 89(XXX)XXXXX, Городской и ГПНС 3XXXXX, Мой номер *65');

-- Заполнение таблицы companies
INSERT INTO companies (name, weight) VALUES 
('Company A', 1),  -- Оставлена только одна компания
('Company B', 1),  -- Добавлена новая компания
('Company C', 1);  -- Добавлена новая компания

-- Заполнение таблицы departments
INSERT INTO departments (name, weight) VALUES 
('Department A1', 1),  -- Оставлено одно подразделение
('Department B1', 1),  -- Добавлено подразделение для Company B
('Department B2', 1),  -- Добавлено еще одно подразделение для Company B
('Department C1', 1),  -- Добавлено подразделение для Company C
('Department A2', 1),  -- Добавлено новое подразделение для Company A
('Department A3', 1),  -- Добавлено новое подразделение для Company A
('Department B3', 1),  -- Добавлено новое подразделение для Company B
('Department B4', 1),  -- Добавлено новое подразделение для Company B
('Department B5', 1),  -- Добавлено новое подразделение для Company B
('Department C2', 1),  -- Добавлено новое подразделение для Company C
('Department C3', 1),  -- Добавлено новое подразделение для Company C
('Department C4', 1);  -- Добавлено новое подразделение для Company C

-- Заполнение таблицы branches
INSERT INTO branches (name, weight) VALUES 
('Branch A1', 1),  -- Добавлена группа для Company A
('Branch B1', 1),  -- Добавлена группа для Company B
('Branch C1', 1);  -- Добавлена группа для Company C

-- Заполнение таблицы positions
INSERT INTO positions (name, weight) VALUES 
('Manager', 1),  -- Оставлена одна должность
('Developer', 1),  -- Добавлена новая должность
('Designer', 1),  -- Добавлена еще одна должность
('Analyst', 1),  -- Добавлена новая должность
('Tester', 1),  -- Добавлена новая должность
('HR', 1),  -- Добавлена новая должность
('Sales', 1),  -- Добавлена новая должность
('Support', 1),  -- Добавлена новая должность
('Marketing', 1),  -- Добавлена новая должность
('Intern', 1);  -- Добавлена новая должность

-- Заполнение таблицы subscribers
INSERT INTO subscribers (company_id, department_id, branch_id, position_id, full_name, internal_phone_number, external_phone_number, weight) 
VALUES 
(1, 1, 1, 1, 'Alice Adams', '1234', '555-0101', 1),
(1, 1, 1, 1, 'Bob Brown', '1235', '555-0102', 1),
(1, 1, 1, 1, 'Charlie Clark', '1236', '555-0103', 1),
(1, 1, 1, 1, 'David Davis', '1237', '555-0104', 1),
(1, 1, 1, 1, 'Eve Edwards', '1238', '555-0105', 1),
(1, 1, 1, 1, 'Frank Foster', '1239', '555-0106', 1),
(1, 1, 1, 1, 'Grace Green', '1240', '555-0107', 1),
(1, 1, 1, 1, 'Hannah Hill', '1241', '555-0108', 1),
(1, 1, 1, 1, 'Ian Irwin', '1242', '555-0109', 1),
(1, 1, 1, 1, 'Jack Johnson', '1243', '555-0110', 1),
(1, 1, 1, 1, 'Kathy King', '1244', '555-0111', 1),
(1, 1, 1, 1, 'Liam Lewis', '1245', '555-0112', 1),
(1, 1, 1, 1, 'Mia Miller', '1246', '555-0113', 1),
(1, 1, 1, 1, 'Noah Nelson', '1247', '555-0114', 1),
(1, 1, 1, 1, 'Olivia O\'Connor', '1248', '555-0115', 1),
(1, 1, 1, 1, 'Paul Parker', '1249', '555-0116', 1),
(1, 1, 1, 1, 'Quinn Quinn', '1250', '555-0117', 1),
(1, 1, 1, 1, 'Rachel Roberts', '1251', '555-0118', 1),
(1, 1, 1, 1, 'Sam Smith', '1252', '555-0119', 1),
(1, 1, 1, 1, 'Tina Taylor', '1253', '555-0120', 1),
(1, 1, 1, 1, 'Uma Underwood', '1254', '555-0121', 1),
(1, 1, 1, 1, 'Victor Vance', '1255', '555-0122', 1),
(1, 1, 1, 1, 'Wendy White', '1256', '555-0123', 1),
(1, 1, 1, 1, 'Xander Xiong', '1257', '555-0124', 1),
(1, 1, 1, 1, 'Yara Young', '1258', '555-0125', 1),
(1, 1, 1, 1, 'Zoe Zimmerman', '1259', '555-0126', 1),
(2, 2, 2, 2, 'Alice Smith', '1260', '555-0127', 1),  -- Добавлен новый сотрудник для Company B
(2, 2, 2, 2, 'Bob Johnson', '1261', '555-0128', 1),  -- Добавлен новый сотрудник для Company B
(2, 2, 2, 2, 'Charlie Brown', '1262', '555-0129', 1),  -- Добавлен новый сотрудник для Company B
(3, 3, 3, 3, 'David Wilson', '1263', '555-0130', 1),  -- Добавлен новый сотрудник для Company C
(3, 3, 3, 3, 'Eve Davis', '1264', '555-0131', 1);  -- Добавлен новый сотрудник для Company C

-- Заполнение таблицы subscribers для новых отделов
INSERT INTO subscribers (company_id, department_id, branch_id, position_id, full_name, internal_phone_number, external_phone_number, weight) 
VALUES 
(1, 2, 1, 1, 'Alice Adams', '1234', '555-0101', 1),  -- Новый сотрудник для Department A2
(1, 2, 1, 1, 'Bob Brown', '1235', '555-0102', 1),  -- Новый сотрудник для Department A2
(1, 2, 1, 1, 'Charlie Clark', '1236', '555-0103', 1),  -- Новый сотрудник для Department A2
(1, 3, 1, 1, 'David Davis', '1237', '555-0104', 1),  -- Новый сотрудник для Department A3
(1, 3, 1, 1, 'Eve Edwards', '1238', '555-0105', 1),  -- Новый сотрудник для Department A3
(1, 3, 1, 1, 'Frank Foster', '1239', '555-0106', 1),  -- Новый сотрудник для Department A3
(2, 3, 2, 2, 'Grace Green', '1240', '555-0107', 1),  -- Новый сотрудник для Department B3
(2, 3, 2, 2, 'Hannah Hill', '1241', '555-0108', 1),  -- Новый сотрудник для Department B3
(2, 3, 2, 2, 'Ian Irwin', '1242', '555-0109', 1),  -- Новый сотрудник для Department B3
(2, 4, 2, 2, 'Jack Johnson', '1243', '555-0110', 1),  -- Новый сотрудник для Department B4
(2, 4, 2, 2, 'Kathy King', '1244', '555-0111', 1),  -- Новый сотрудник для Department B4
(2, 4, 2, 2, 'Liam Lewis', '1245', '555-0112', 1),  -- Новый сотрудник для Department B4
(3, 5, 3, 3, 'Mia Miller', '1246', '555-0113', 1),  -- Новый сотрудник для Department C2
(3, 5, 3, 3, 'Noah Nelson', '1247', '555-0114', 1),  -- Новый сотрудник для Department C2
(3, 5, 3, 3, 'Olivia O\'Connor', '1248', '555-0115', 1),  -- Новый сотрудник для Department C2
(3, 6, 3, 3, 'Paul Parker', '1249', '555-0116', 1),  -- Новый сотрудник для Department C3
(3, 6, 3, 3, 'Quinn Quinn', '1250', '555-0117', 1),  -- Новый сотрудник для Department C3
(3, 6, 3, 3, 'Rachel Roberts', '1251', '555-0118', 1);  -- Новый сотрудник для Department C3

-- Генерация дополнительных записей до 1000 абонентов
INSERT INTO subscribers (company_id, department_id, branch_id, position_id, full_name, internal_phone_number, external_phone_number, weight) 
SELECT 
    1 AS company_id,     -- Указана одна компания
    1 AS department_id,  -- Указан один отдел
    1 AS branch_id,       -- Указана одна группа
    1 AS position_id,    -- Указана одна должность
    CONCAT('Subscriber ', seq) AS full_name,  -- Имя абонента
    CONCAT('1', LPAD(seq, 3, '0')) AS internal_phone_number,  -- Внутренний номер
    CONCAT('555-', LPAD(seq, 4, '0')) AS external_phone_number,  -- Внешний номер
    1 AS weight  -- Указан вес
FROM (
    SELECT @rownum := @rownum + 1 AS seq
    FROM (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) t1,
         (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) t2,
         (SELECT @rownum := 0) t3
) AS numbers
WHERE seq <= 994;  -- Добавляем до 1000 абонентов

-- Удаление таблиц в обратном порядке их создания
-- DROP TABLE IF EXISTS subscribers;
-- DROP TABLE IF EXISTS positions;
-- DROP TABLE IF EXISTS branches;
-- DROP TABLE IF EXISTS departments;
-- DROP TABLE IF EXISTS companies;