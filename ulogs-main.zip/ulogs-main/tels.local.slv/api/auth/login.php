<?php

header('Content-Type: application/json');
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['login'] ?? '';
    $password = $_POST['password'] ?? '';

    // Заглушка для проверки авторизации
    if ($username === 'admin' && $password === 'passcode') {
        $_SESSION['sessionId'] = session_id();
        echo json_encode(['success' => true, 'message' => 'Авторизация успешна', 'sessionId' => $_SESSION['sessionId']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Неверные учетные данные']);
    }
}