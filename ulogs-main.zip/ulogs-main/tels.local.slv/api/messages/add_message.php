<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['message_key', 'message_value'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'Название ключа и сообщения не может быть пустым']);
        exit;
    }

    $messageKey = trim($_POST['message_key']);
    $messageValue = trim($_POST['message_value']);

    try {
        $stmt = $pdo->prepare("INSERT INTO messages (message_key, message_value) VALUES (?, ?)");
        $stmt->execute([$messageKey, $messageValue]);

        $messageId = $pdo->lastInsertId();

        $stmt = $pdo->prepare("SELECT * FROM messages WHERE id = ?");
        $stmt->execute([$messageId]);
        
        $message = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $message['id'],
            'message_key' => $message['message_key'],
            'message_value' => $message['message_value']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при добавлении сообщения: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
