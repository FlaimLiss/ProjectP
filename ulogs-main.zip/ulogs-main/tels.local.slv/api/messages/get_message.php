<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $message_key = $_GET['message_key'] ?? '';

    if (empty($message_key)) {
        echo json_encode(['success' => false, 'message' => 'Ключ не может быть пустым']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT message_value FROM messages WHERE message_key = :message_key");
        $stmt->bindParam(':message_key', $message_key);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            echo json_encode(['success' => true, 'message_value' => $result['message_value']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Строка для ключа ' . $message_key . ' не найдена']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?> 