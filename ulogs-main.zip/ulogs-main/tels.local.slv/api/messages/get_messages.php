<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $letter = $_GET['letter'] ?? '';

    $query = "SELECT id, message_key, message_value FROM messages WHERE 1=1";

    $params = [];
    
    if ($letter) {
        $query .= " AND UPPER(LEFT(message_key, 1)) = UPPER(:letter)";
        $params['letter'] = $letter;
    }

    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($messages) {
            echo json_encode(['success' => true, 'messages' => $messages]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Сообщения не найдены']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?> 