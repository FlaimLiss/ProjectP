<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['message_id', 'message_key', 'message_value'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'ID сообщения, ключ и значение не могут быть пустыми']);
        exit;
    }

    $messageId = intval($_POST['message_id']);
    $messageKey = trim($_POST['message_key']);
    $messageValue = trim($_POST['message_value']);

    try {
        $stmt = $pdo->prepare("UPDATE messages SET message_key = ?, message_value = ? WHERE id = ?");
        $stmt->execute([$messageKey, $messageValue, $messageId]);

        if ($stmt->rowCount() === 0) {
            echo json_encode(['success' => false, 'message' => 'Сообщение не найдено или данные не изменились']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM messages WHERE id = ?");
        $stmt->execute([$messageId]);
        
        $message = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $message['id'],
            'message_key' => $message['message_key'],
            'message_value' => $message['message_value']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при обновлении сообщения: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
