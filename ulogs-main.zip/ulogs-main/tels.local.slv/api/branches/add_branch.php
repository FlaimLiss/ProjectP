<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['branch_name'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'Название отдела не может быть пустым']);
        exit;
    }

    $branchName = trim($_POST['branch_name']);
    $branchWeight = isset($_POST['branch_weight']) ? intval($_POST['branch_weight']) : 0;

    try {
        if (empty($branchWeight)) {
            $stmt = $pdo->prepare("INSERT INTO branches (name) VALUES (?)");
            $stmt->execute([$branchName]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO branches (name, weight) VALUES (?, ?)");
            $stmt->execute([$branchName, $branchWeight]);
        }

        $branchId = $pdo->lastInsertId();

        $stmt = $pdo->prepare("SELECT * FROM branches WHERE id = ?");
        $stmt->execute([$branchId]);
        
        $branch = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $branch['id'],
            'name' => $branch['name'],
            'weight' => $branch['weight']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при добавлении отдела: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
