<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['branch_id', 'branch_name'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'ID отдела и название не могут быть пустыми']);
        exit;
    }

    $branchId = intval($_POST['branch_id']);
    $branchName = trim($_POST['branch_name']);
    $branchWeight = isset($_POST['branch_weight']) ? intval($_POST['branch_weight']) : 0;

    try {
        $stmt = $pdo->prepare("UPDATE branches SET name = ?, weight = ? WHERE id = ?");
        $stmt->execute([$branchName, $branchWeight, $branchId]);

        if ($stmt->rowCount() === 0) {
            echo json_encode(['success' => false, 'message' => 'Отдел не найден или данные не изменились']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM branches WHERE id = ?");
        $stmt->execute([$branchId]);
        
        $branch = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $branch['id'],
            'name' => $branch['name'],
            'weight' => $branch['weight']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при обновлении данных отдела: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
