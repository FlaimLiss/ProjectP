<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['branch_id'])) {
    $branchId = $_POST['branch_id'];
    if ($branchId) {
        $stmt = $pdo->prepare("DELETE FROM branches WHERE id = :id");
        $stmt->bindParam(':id', $branchId, PDO::PARAM_INT);
        $stmt->execute();
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Неверный ID отдела']);
    }
    exit;
}
