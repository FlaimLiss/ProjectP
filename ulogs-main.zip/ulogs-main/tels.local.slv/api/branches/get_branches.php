<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $letter = $_GET['letter'] ?? '';

    $query = "  SELECT b.id, b.name, b.weight
              FROM branches b 
              WHERE 1=1";

    $params = [];

    if ($letter) {
        $query .= " AND UPPER(LEFT(b.name, 1)) = UPPER(:letter)";
        $params['letter'] = $letter;
    }

    $query .= " ORDER BY b.weight DESC, UPPER(b.name)";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $branches = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($branches) {
        echo json_encode(['success' => true, 'branches' => $branches]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Отделы не найдены']);
    }
    exit;
}
