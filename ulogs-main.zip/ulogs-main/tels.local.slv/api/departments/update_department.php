<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['department_id', 'department_name'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'ID подразделения и название не могут быть пустыми']);
        exit;
    }

    $departmentId = intval($_POST['department_id']);
    $departmentName = trim($_POST['department_name']);
    $departmentWeight = isset($_POST['department_weight']) ? intval($_POST['department_weight']) : 0;

    try {
        $stmt = $pdo->prepare("UPDATE departments SET name = ?, weight = ? WHERE id = ?");
        $stmt->execute([$departmentName, $departmentWeight, $departmentId]);

        if ($stmt->rowCount() === 0) {
            echo json_encode(['success' => false, 'message' => 'Подразделение не найдено или данные не изменились']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM departments WHERE id = ?");
        $stmt->execute([$departmentId]);
        
        $department = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $department['id'],
            'name' => $department['name'],
            'weight' => $department['weight']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при обновлении данных подразделения: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
