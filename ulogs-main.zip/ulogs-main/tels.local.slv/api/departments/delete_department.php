<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['department_id'])) {
    $departmentId = $_POST['department_id'];
    if ($departmentId) {
        $stmt = $pdo->prepare("DELETE FROM departments WHERE id = :id");
        $stmt->bindParam(':id', $departmentId, PDO::PARAM_INT);
        $stmt->execute();
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Неверный ID подразделения']);
    }
    exit;
}
