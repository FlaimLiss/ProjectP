<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['department_name'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'Название подразделения не может быть пустым']);
        exit;
    }

    $departmentName = trim($_POST['department_name']);
    $departmentWeight = isset($_POST['department_weight']) ? intval($_POST['department_weight']) : 0;

    try {
        if (empty($departmentWeight)) {
            $stmt = $pdo->prepare("INSERT INTO departments (name) VALUES (?)");
            $stmt->execute([$departmentName]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO departments (name, weight) VALUES (?, ?)");
            $stmt->execute([$departmentName, $departmentWeight]);
        }

        $departmentId = $pdo->lastInsertId();

        $stmt = $pdo->prepare("SELECT * FROM departments WHERE id = ?");
        $stmt->execute([$departmentId]);
        
        $department = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $department['id'],
            'name' => $department['name'],
            'weight' => $department['weight']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при добавлении подразделения: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
