<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $letter = $_GET['letter'] ?? '';

    $query = "  SELECT d.id, d.name, d.weight
              FROM departments d 
              WHERE 1=1";

    $params = [];

    if ($letter) {
        $query .= " AND UPPER(LEFT(d.name, 1)) = UPPER(:letter)";
        $params['letter'] = $letter;
    }

    $query .= " ORDER BY d.weight DESC, UPPER(d.name)";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($departments) {
        echo json_encode(['success' => true, 'departments' => $departments]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Подразделения не найдены']);
    }
    exit;
}
