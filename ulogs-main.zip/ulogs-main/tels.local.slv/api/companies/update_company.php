<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['company_id', 'company_name'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'ID организации и название не могут быть пустыми']);
        exit;
    }

    $companyId = intval($_POST['company_id']);
    $companyName = trim($_POST['company_name']);
    $companyWeight = isset($_POST['company_weight']) ? intval($_POST['company_weight']) : 0;

    try {
        $stmt = $pdo->prepare("UPDATE companies SET name = ?, weight = ? WHERE id = ?");
        $stmt->execute([$companyName, $companyWeight, $companyId]);

        if ($stmt->rowCount() === 0) {
            echo json_encode(['success' => false, 'message' => 'Организация не найдена или данные не изменились']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
        $stmt->execute([$companyId]);
        
        $company = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $company['id'],
            'name' => $company['name'],
            'weight' => $company['weight']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при обновлении данных компании: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
