<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['company_name'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'Название организации не может быть пустым']);
        exit;
    }

    $companyName = trim($_POST['company_name']);
    $companyWeight = isset($_POST['company_weight']) ? intval($_POST['company_weight']) : 0;

    try {
        if (empty($companyWeight)) {
            $stmt = $pdo->prepare("INSERT INTO companies (name) VALUES (?)");
            $stmt->execute([$companyName]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO companies (name, weight) VALUES (?, ?)");
            $stmt->execute([$companyName, $companyWeight]);
        }

        $companyId = $pdo->lastInsertId();

        $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
        $stmt->execute([$companyId]);
        
        $company = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $company['id'],
            'name' => $company['name'],
            'weight' => $company['weight']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при добавлении организации: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
