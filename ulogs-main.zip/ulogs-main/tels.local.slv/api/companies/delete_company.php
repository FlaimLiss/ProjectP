<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['company_id'])) {
    $companyId = $_POST['company_id'];
    if ($companyId) {
        $stmt = $pdo->prepare("DELETE FROM companies WHERE id = :id");
        $stmt->bindParam(':id', $companyId, PDO::PARAM_INT);
        $stmt->execute();
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Неверный ID компании']);
    }
    exit;
}
