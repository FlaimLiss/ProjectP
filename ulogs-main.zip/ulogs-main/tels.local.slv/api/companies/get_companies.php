<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $letter = $_GET['letter'] ?? '';

    $query = "  SELECT c.id, c.name, c.weight
              FROM companies c 
              WHERE 1=1";

    $params = [];

    if ($letter) {
        $query .= " AND UPPER(LEFT(c.name, 1)) = UPPER(:letter)";
        $params['letter'] = $letter;
    }

    $query .= " ORDER BY c.weight DESC, UPPER(c.name)";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($companies) {
        echo json_encode(['success' => true, 'companies' => $companies]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Компании не найдены']);
    }
    exit;
}
