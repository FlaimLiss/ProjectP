<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['subscriber_id'])) {
    $subscriberId = $_POST['subscriber_id'];
    if ($subscriberId) {
        $stmt = $pdo->prepare("DELETE FROM subscribers WHERE id = :id");
        $stmt->bindParam(':id', $subscriberId, PDO::PARAM_INT);
        $stmt->execute();
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Неверный ID абонента']);
    }
    exit;
}
