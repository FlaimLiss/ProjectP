<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $companyId = $_POST['company_id'];
    $departmentId = $_POST['department_id'];
    $branchId = $_POST['branch_id'];
    $positionId = $_POST['position_id'];
    $fullName = trim($_POST['full_name']);
    $internalPhoneNumber = trim($_POST['internal_phone_number']);
    $externalPhoneNumber = trim($_POST['external_phone_number']);
    $weight = trim($_POST['weight']);

    if (empty($companyId) || empty($departmentId) ||empty($positionId) || empty($fullName) || empty($internalPhoneNumber)) {
        echo json_encode(['success' => false, 'message' => 'Все поля кроме ID отдела, внешнего номера и веса должны быть заполнены']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO subscribers (company_id, department_id, branch_id, position_id, full_name, internal_phone_number, external_phone_number, weight) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $companyId,
            $departmentId,
            $branchId ?: null,
            $positionId,
            $fullName,
            $internalPhoneNumber,
            $externalPhoneNumber ?: null,
            $weight ?: 0
        ]);
        echo json_encode(['success' => true, 'message' => 'Абонент успешно добавлен']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при добавлении абонента: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
