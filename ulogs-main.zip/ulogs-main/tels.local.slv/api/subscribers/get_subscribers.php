<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $companyId = $_GET['company_id'] ?? null;
    $letter = $_GET['letter'] ?? '';
    $search = $_GET['search'] ?? '';

    $query = "SELECT s.id, 
                    s.full_name, 
                    s.internal_phone_number, 
                    s.external_phone_number, 
                    s.weight, 
                    c.name AS company_name, 
                    c.weight AS company_weight, 
                    d.name AS department_name, 
                    d.weight AS department_weight, 
                    b.name AS branch_name, 
                    b.weight AS branch_weight, 
                    p.name AS position_name, 
                    p.weight AS position_weight
              FROM subscribers s 
              JOIN departments d ON s.department_id = d.id 
              LEFT JOIN branches b ON s.branch_id = b.id
              JOIN positions p ON s.position_id = p.id
              JOIN companies c ON s.company_id = c.id
              WHERE 1=1";

    $params = [];

    if ($companyId) {
        $query .= " AND c.id = :companyId";
        $params['companyId'] = $companyId;
    }

    if ($letter) {
        $query .= " AND UPPER(LEFT(s.full_name, 1)) = UPPER(:letter)";
        $params['letter'] = $letter;
    }

    if ($search) {
        $query .= " AND (s.full_name LIKE ? OR c.name LIKE ? OR d.name LIKE ? OR b.name LIKE ? OR p.name LIKE ? OR s.internal_phone_number LIKE ? OR s.external_phone_number LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    $query .= " ORDER BY d.weight DESC, b.weight DESC, p.weight DESC, s.weight DESC, d.name, b.name, s.full_name";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $subscribers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($subscribers) {
        echo json_encode(['success' => true, 'subscribers' => $subscribers]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Абоненты не найдены']);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['subscriber_id'])) {
    $subscriberId = $_GET['subscriber_id'];
    $stmt = $pdo->prepare("SELECT s.full_name, c.name AS company_name, d.name AS department_name, b.name AS branch_name, p.name AS position_name, s.internal_phone_number
                           FROM subscribers s 
                           JOIN companies c ON s.company_id = c.id
                           JOIN departments d ON s.department_id = d.id 
                           JOIN branches b ON s.branch_id = b.id
                           JOIN positions p ON s.position_id = p.id 
                           WHERE s.id = :id");
    $stmt->bindParam(':id', $subscriberId, PDO::PARAM_INT);
    $stmt->execute();
    $subscriber = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($subscriber) {
        echo json_encode(['success' => true, 'subscriber' => $subscriber]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Абонент не найден']);
    }
    exit;
}
