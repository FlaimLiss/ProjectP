<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['subscriber_id', 'company_id', 'department_id', 'position_id', 'full_name', 'internal_phone_number'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'Все поля кроме ID отдела, внешнего номера и веса должны быть заполнены']);
        exit;
    }

    $subscriberId = $_POST['subscriber_id'];
    $companyId = $_POST['company_id'];
    $departmentId = $_POST['department_id'];
    $branchId = isset($_POST['branch_id']) && trim($_POST['branch_id']) !== '' ? intval(trim($_POST['branch_id'])) : null;
    $positionId = $_POST['position_id'];
    $fullName = trim($_POST['full_name']);
    $internalPhoneNumber = trim($_POST['internal_phone_number']);
    $externalPhoneNumber = isset($_POST['external_phone_number']) ? trim($_POST['external_phone_number']) : null;
    $weight = isset($_POST['weight']) ? intval($_POST['weight']) : 0;

    try {
        $stmt = $pdo->prepare(
            "UPDATE subscribers SET 
                company_id = ?, 
                department_id = ?, 
                branch_id = ?, 
                position_id = ?, 
                full_name = ?, 
                internal_phone_number = ?, 
                external_phone_number = ?, 
                weight = ? 
            WHERE id = ?");
        $stmt->execute([
            $companyId, 
            $departmentId, 
            $branchId === null ? null : $branchId, 
            $positionId, 
            $fullName, 
            $internalPhoneNumber, 
            $externalPhoneNumber === null ? null : $externalPhoneNumber,
            $weight,
            $subscriberId
        ]);

        if ($stmt->rowCount() === 0) {
            echo json_encode(['success' => false, 'message' => 'Сотрудник не найден или данные не изменились']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT 
                c.name AS company_name,
                d.name AS department_name,
                b.name AS branch_name,
                p.name AS position_name, 
                s.full_name, 
                s.internal_phone_number,
                s.external_phone_number,
                s.weight
                FROM subscribers s
                LEFT JOIN branches b ON s.branch_id = b.id
                JOIN departments d ON s.department_id = d.id
                JOIN positions p ON s.position_id = p.id
                JOIN companies c ON s.company_id = c.id
                WHERE s.id = ?");
        $stmt->execute([$subscriberId]);

        $subscriber = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'companyName' => $subscriber['company_name'],
            'departmentName' => $subscriber['department_name'],
            'branchName' => $subscriber['branch_name'],
            'positionName' => $subscriber['position_name'],
            'fullName' => $subscriber['full_name'],
            'internalPhoneNumber' => $subscriber['internal_phone_number'],
            'externalPhoneNumber' => $subscriber['external_phone_number'],
            'weight' => $subscriber['weight']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при обновлении данных абонента: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
