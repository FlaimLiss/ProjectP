<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['subscriber_id'])) {
    $subscriberId = $_GET['subscriber_id'];
    $stmt = $pdo->prepare("SELECT s.full_name, c.name AS company_name, d.name AS department_name, p.name AS position_name, s.internal_phone_number, s.external_phone_number, s.weight
                           FROM subscribers s 
                           JOIN companies c ON s.company_id = c.id 
                           JOIN departments d ON s.department_id = d.id
                           JOIN positions p ON s.position_id = p.id
                           WHERE s.id = :id");
    $stmt->bindParam(':id', $subscriberId, PDO::PARAM_INT);
    $stmt->execute();
    $subscriber = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($subscriber) {
        echo json_encode(['success' => true, 'subscriber' => $subscriber]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Абонент не найден']);
    }
    exit;
}
