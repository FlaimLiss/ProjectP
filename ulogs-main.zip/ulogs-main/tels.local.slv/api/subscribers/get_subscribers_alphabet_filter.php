<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $companyId = $_GET['company_id'] ?? null;

    $query = "SELECT UPPER(LEFT(s.full_name, 1)) AS letter, COUNT(*) AS count
              FROM subscribers s 
              JOIN companies c ON s.company_id = c.id
              WHERE 1=1";

    $params = [];

    if ($companyId) {
        $query .= " AND c.id = :companyId";
        $params['companyId'] = $companyId;
    }

    $query .= " GROUP BY letter ORDER BY letter";

    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $letters = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'letters' => $letters]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
    exit;
}