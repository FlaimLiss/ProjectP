<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['position_name'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'Название должности не может быть пустым']);
        exit;
    }

    $positionName = trim($_POST['position_name']);
    $positionWeight = isset($_POST['position_weight']) ? intval($_POST['position_weight']) : 0;

    try {
        if (empty($positionWeight)) {
            $stmt = $pdo->prepare("INSERT INTO positions (name) VALUES (?)");
            $stmt->execute([$positionName]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO positions (name, weight) VALUES (?, ?)");
            $stmt->execute([$positionName, $positionWeight]);
        }

        $positionId = $pdo->lastInsertId();

        $stmt = $pdo->prepare("SELECT * FROM positions WHERE id = ?");
        $stmt->execute([$positionId]);
        
        $position = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $position['id'],
            'name' => $position['name'],
            'weight' => $position['weight']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при добавлении должности: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
