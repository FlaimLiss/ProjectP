<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $letter = $_GET['letter'] ?? '';

    $query = "  SELECT p.id, p.name, p.weight
              FROM positions p 
              WHERE 1=1";

    $params = [];

    if ($letter) {
        $query .= " AND UPPER(LEFT(p.name, 1)) = UPPER(:letter)";
        $params['letter'] = $letter;
    }

    $query .= " ORDER BY p.weight DESC, UPPER(p.name)";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $positions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($positions) {
        echo json_encode(['success' => true, 'positions' => $positions]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Должности не найдены']);
    }
    exit;
}
