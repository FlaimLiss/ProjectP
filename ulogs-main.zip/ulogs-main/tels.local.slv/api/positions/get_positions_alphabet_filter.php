<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = "SELECT UPPER(LEFT(p.name, 1)) AS letter, COUNT(*) AS count
              FROM positions p 
              WHERE 1=1";

    $params = [];

    $query .= " GROUP BY letter ORDER BY letter";
    
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $letters = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'letters' => $letters]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
    exit;
}