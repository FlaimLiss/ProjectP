<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['position_id'])) {
    $positionId = $_POST['position_id'];
    if ($positionId) {
        $stmt = $pdo->prepare("DELETE FROM positions WHERE id = :id");
        $stmt->bindParam(':id', $positionId, PDO::PARAM_INT);
        $stmt->execute();
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Неверный ID должности']);
    }
    exit;
}
