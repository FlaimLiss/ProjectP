<?php
include '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['position_id', 'position_name'];
    $missingFields = array_filter($requiredFields, fn($field) => empty(trim($_POST[$field])));

    if (!empty($missingFields)) {
        echo json_encode(['success' => false, 'message' => 'ID должности и название не могут быть пустыми']);
        exit;
    }

    $positionId = intval($_POST['position_id']);
    $positionName = trim($_POST['position_name']);
    $positionWeight = isset($_POST['position_weight']) ? intval($_POST['position_weight']) : 0;

    try {
        $stmt = $pdo->prepare("UPDATE positions SET name = ?, weight = ? WHERE id = ?");
        $stmt->execute([$positionName, $positionWeight, $positionId]);

        if ($stmt->rowCount() === 0) {
            echo json_encode(['success' => false, 'message' => 'Должность не найдена или данные не изменились']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM positions WHERE id = ?");
        $stmt->execute([$positionId]);
        
        $position = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'id' => $position['id'],
            'name' => $position['name'],
            'weight' => $position['weight']
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка при обновлении данных должности: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
