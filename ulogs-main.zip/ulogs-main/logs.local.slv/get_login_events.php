<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $search = $_GET['search'] ?? '';
    $page = (int)($_GET['page'] ?? 1); // Номер страницы
    $limit = (int)($_GET['limit'] ?? 20); // Количество записей на странице
    $offset = ($page - 1) * $limit; // Смещение для SQL-запроса

    $query = "SELECT * FROM user_logs";

    $params = [];
    
    if ($search && strlen($search) > 0) {
		$query = "SELECT * FROM user_logs WHERE login LIKE ? OR fullName LIKE ? OR hostname LIKE ? OR osVersion LIKE ? OR ipAddress LIKE ? OR macAddress LIKE ? OR processorModel LIKE ? OR mainboardModel LIKE ? OR totalMemory LIKE ?";
        $params = ["%$search%", "%$search%", "%$search%", "%$search%", "%$search%", "%$search%", "%$search%", "%$search%", "%$search%"];
	}

    try {
        $query .= " ORDER BY createdAt DESC LIMIT ? OFFSET ?";
        $params[] = $limit + 1; // Лимит + 1
        $params[] = $offset; // Смещение
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $hasNextPage = count($logs) > $limit;
        if ($hasNextPage) {
            array_pop($logs); // Убираем лишнюю запись
        }

        if ($logs) {
            echo json_encode([
                'success' => true,
                'logs' => $logs,
                'currentPage' => $page,
                'hasNextPage' => $hasNextPage
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'События авторизации не найдены']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?> 