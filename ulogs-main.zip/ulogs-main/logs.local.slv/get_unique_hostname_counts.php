<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Запрос для подсчета уникальных хостнеймов
        $query = "SELECT COUNT(DISTINCT hostname) AS unique_hostname_count FROM user_logs";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'uniqueHostnameCount' => (int)$result['unique_hostname_count']
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Не удалось получить данные']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?> 