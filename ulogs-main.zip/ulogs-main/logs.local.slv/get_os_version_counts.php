<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = "SELECT osVersion, COUNT(DISTINCT macAddress) as count FROM user_logs GROUP BY osVersion";

    try {
    	$stmt = $pdo->prepare($query);
    	$stmt->execute([]);
    	$osVersionCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($osVersionCounts) {
            echo json_encode(['success' => true, 'osVersionCounts' => $osVersionCounts]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Версии ОС не найдены']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?> 