<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Запрос для подсчета уникальных логинов
        $query = "SELECT COUNT(DISTINCT login) AS unique_login_count FROM user_logs";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'uniqueLoginCount' => (int)$result['unique_login_count']
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Не удалось получить данные']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?> 