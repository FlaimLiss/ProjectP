<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Запрос для подсчета уникальных MAC-адресов
        $query = "SELECT COUNT(DISTINCT macAddress) AS unique_mac_count FROM user_logs";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'uniqueMacCount' => (int)$result['unique_mac_count']
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Не удалось получить данные']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?> 