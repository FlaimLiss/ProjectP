<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Запрос для подсчета уникальных версий процессоров
    $query = "SELECT processorModel, COUNT(DISTINCT macAddress) as count FROM user_logs GROUP BY processorModel";

    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute([]);
        $cpuVersionCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($cpuVersionCounts) {
            echo json_encode(['success' => true, 'cpuVersionCounts' => $cpuVersionCounts]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Версии процессоров не найдены']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?> 