<?php
// Подключение файла с параметрами подключения к базе данных
require 'db.php';

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'error' => true,
        'message' => 'Database connection error: ' . $e->getMessage()
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $fullName = $_POST['fullName'] ?? '';
    $isAdmin = $_POST['isAdmin'] ?? 0;
    $hostname = $_POST['hostname'] ?? '';
    $osVersion = $_POST['osVersion'] ?? '';
    $ipAddress = $_POST['ipAddress'] ?? '';
    $macAddress = $_POST['macAddress'] ?? '';
    $processorModel = $_POST['processorModel'] ?? '';
    $mainboardModel = $_POST['mainboardModel'] ?? '';
    $totalMemory = $_POST['totalMemory'] ?? '';

    try {
        // Сохраняем данные в таблицу
        $stmt = $pdo->prepare(
            'INSERT INTO user_logs (login, fullName, isAdmin, hostname, osVersion, ipAddress, macAddress, processorModel, mainboardModel, totalMemory) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$login, $fullName, $isAdmin, $hostname, $osVersion, $ipAddress, $macAddress, $processorModel, $mainboardModel, $totalMemory]);

        // Проверяем количество записей для данного пользователя и удаляем старые, если их больше 10
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM user_logs WHERE login = ?');
        $stmt->execute([$login]);
        $count = $stmt->fetchColumn();

        if ($count > 10) {
            $stmt = $pdo->prepare('DELETE FROM user_logs WHERE login = ? ORDER BY createdAt ASC LIMIT ?');
            $stmt->execute([$login, $count - 10]);
        }

        // Возвращаем успешный ответ
        echo json_encode([
            'success' => true,
            'message' => 'Request successfully'
        ]);
    } catch (\PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'error' => true,
            'message' => 'Request failed: ' . $e->getMessage()
        ]);
    }
}
